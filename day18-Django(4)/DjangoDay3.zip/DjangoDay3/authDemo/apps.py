from django.apps import AppConfig


class AuthdemoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'authDemo'
