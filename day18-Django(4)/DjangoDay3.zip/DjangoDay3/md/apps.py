from django.apps import AppConfig


class MdConfig(AppConfig):
    name = 'md'
